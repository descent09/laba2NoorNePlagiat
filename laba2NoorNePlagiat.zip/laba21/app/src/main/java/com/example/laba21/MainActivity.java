package com.example.laba21;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity{ //implements View.OnClickListener{

    //private Button actorich1 = null;
    //private Button actorich2 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //actorich1 = findViewById(R.id.actorich1);
        //actorich1.setOnClickListener(this);
        //actorich2 = findViewById(R.id.actorich2);
        //actorich2.setOnClickListener(this);
    }

    /* @Override
    *public void onClick(View v) {
         switch (v.getId()){
             case R.id.actorich1:
                 Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://ru.wikipedia.org/wiki/%D0%A7%D0%B0%D0%BD,_%D0%94%D0%B6%D0%B5%D0%BA%D0%B8"));
                 startActivity(intent);
                 //Intent intent = new Intent(this, actor1.class);
                 //startActivity(intent);
                 break;

             case R.id.actorich2:
              Intent intent2 = new Intent(this, actor2.class);
              startActivity(intent2);
              break;



         }*/
    public void act(View view){
        Intent intent2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://ru.wikipedia.org/wiki/%D0%A7%D0%B0%D0%BD,_%D0%94%D0%B6%D0%B5%D0%BA%D0%B8"));
        startActivity(intent2);
    }
    public void act1(View view){
        Intent intent3 = new Intent(this, actor2.class);
        startActivity(intent3);
    }
}




